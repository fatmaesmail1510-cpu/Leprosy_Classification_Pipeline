# Supplementary data: An Image-Based Deep Learning Framework for Leprosy Diagnosis and Severity Assessment

Everything here is derived from the experiments reported in the manuscript. Image files are NOT included (they come from public sources, see below); paths are relative to the dataset roots.

## Contents
- `splits/stage1_split_manifest.csv` – Stage 1 split (70/15/15, stratified, seed 42): path, label, split, cls, y. Leprosy 470/101/101, non-leprosy 2965/636/636.
- `splits/stage2_split_manifest.csv` – Stage 2 split. Hold-out = Stage 1 test leprosy images (n=101: 32 TT, 50 LL, 19 BB); pool = Stage 1 train+val leprosy (n=571), used for 5-fold CV.
- `stage1/stage1_test_probs.csv` – per-image probabilities (EfficientNet-B3, ConvNeXt-Tiny, ResNet-50, soft-voting ensemble) on the internal test set.
- `stage2/` – hold-out predictions (`stage2_holdout_predictions.csv`), hold-out report, 5-fold raw results, ImageNet vs Stage 1-initialised comparison.
- `external/` – per-image probabilities on the two external sets (Roboflow, DermNet), external metrics, threshold analysis, and the Roboflow images excluded for folder/COCO label conflicts.
- `ablation/` – 8 Stage 1 EfficientNet-B3 runs (full x3 seeds 42/43/44, plain x3 seeds 42/43/44, no_sampler, no_labelsmooth, basic_aug; seed 42), per-run test and external probabilities, training history, `all_runs_summary.csv`, and the Colab notebook that produced them.
- `leakage_checks/` – perceptual-hash (pHash/dHash, near-duplicate Hamming threshold 6) nearest-neighbour distances: internal test vs train, external sets vs training pool.
- `final_summary.json` – split counts, software versions, model complexity.

## Environment
PyTorch 2.11.0+cu130, torchvision 0.26.0+cu130, GPU Tesla T4 (Google Colab). Seeds: 42 (split and main runs); 43, 44 for repeats.

## Data sources
Training/internal: "Atlas dan ISIC2019 (31 classes)" compilation (Kaggle). External: AI-Leprosy v1 (Roboflow Universe, COCO export) and DermNet. Please obtain images from the original sources under their licences.

## Statistical notes
Bootstrap CIs: percentile, 1000 resamples, seed 42. Proportion CIs: Wilson. Run-to-run variation across seeds is as large as differences between ablation configurations, so single-run differences should not be over-interpreted.
